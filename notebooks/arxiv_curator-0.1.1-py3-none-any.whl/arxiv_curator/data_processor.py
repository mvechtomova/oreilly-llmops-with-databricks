import arxiv
import datetime
from pyspark.sql import SparkSession
from pyspark.sql import types as T, functions as F
import os
from loguru import logger

# COMMAND ----------

class ArxivPaperProcessor:
    def __init__(self, config, spark: SparkSession):
        self.spark = spark
        self.catalog_name = config.catalog_name
        self.schema_name = config.schema_name
        self.volume_name = config.volume_name
        self.table_name = config.table_name
        max_published = spark.sql(
            f"SELECT MAX(published) as max_pub FROM {self.catalog_name}.{self.schema_name}.{self.table_name}"
            ).collect()
        if max_published and max_published[0]['max_pub'] is not None:
            self.start_date = str(max_published[0]['max_pub'])
        else:
            self.start_date = (datetime.datetime.now(datetime.UTC) - datetime.timedelta(days=2)).strftime("%Y%m%d%H%M")
        self.end_date = datetime.datetime.now(datetime.UTC).strftime("%Y%m%d%H%M")
        self.paper_ids = spark.sql(f"SELECT paper_id FROM {catalog_name}.{schema_name}.arxiv_papers WHERE published = {max_published}").rdd.flatMap(lambda x: x).collect()

    def download_papers_store_metadata(self, spark: SparkSession):
        # search for papers in arxiv in the cs.AI category
        # https://arxiv.org/category_taxonomy
        # interested in the AI category within computer science:
        # cs.AI - Artificial Intelligence

        # The expected format for date is [YYYYMMDDTTTT+TO+YYYYMMDDTTTT]
        # were the TTTT is provided in 24 hour time to the minute, in GMT.
        client = arxiv.Client()
        search = arxiv.Search(
            query=f"cat:cs.AI AND submittedDate:[{self.start_date} TO {self.end_date}]"
        )
        papers = client.results(search)
        records = []
        for paper in papers:
            paper_id = paper.get_short_id()
            if paper_id not in self.paper_ids:
                pdf_dir = f"/Volumes/{self.catalog_name}/{self.schema_name}/{self.volume_name}/{self.end_date}"
                os.makedirs(pdf_dir, exist_ok=True)
                paper.download_pdf(dirpath=pdf_dir, filename=f"{paper_id}.pdf")
                logger.info(f"Downloaded paper {paper_id} to {pdf_dir}/{paper_id}.pdf")
                records.append({
                    "paper_id": paper_id,
                    "title": paper.title,
                    "authors": [author.name for author in paper.authors],
                    "summary": paper.summary,
                    "pdf_url": paper.pdf_url,
                    "published": int(paper.published.strftime("%Y%m%d%H%M")),
                    "volume_path": f"{pdf_dir}/{paper_id}.pdf"
                })
            schema = T.StructType([
                T.StructField("paper_id", T.StringType(), False),
                T.StructField("title", T.StringType(), True),
                T.StructField("authors", T.ArrayType(T.StringType()), True),
                T.StructField("summary", T.StringType(), True),
                T.StructField("pdf_url", T.StringType(), True),
                T.StructField("published", T.LongType(), True),
                T.StructField("volume_path", T.StringType(), True),
            ])
            if len(records) > 0:
                df = self.spark.createDataFrame(records, schema=schema) \
                    .withColumn("ingest_ts", F.current_timestamp())

                # write to UC
                df.write \
                .format("delta") \
                .mode("append") \
                .saveAsTable(f"{self.catalog_name}.{self.schema_name}.{self.table_name}")
    def process_papers(self):
        self.download_papers_store_metadata(self.spark)

# COMMAND ----------

spark = SparkSession.builder.getOrCreate()

catalog_name = "mlops_dev"
schema_name = "arxiv"
volume_name = "arxiv_papers"


# COMMAND ----------


